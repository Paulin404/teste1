const gcpf = () => { 
	return `
	*CPFS:*
• hehe

000-000-00

Vrau domina ta? 🐊🚩
`
}
exports.gcpf = gcpf